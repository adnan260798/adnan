
<html>
    <head>
        <title>Gestion Pointage - Page invalide</title>
    </head>
    <body style="width: 100%;height: 100vh;text-align: center;">
        <h1 style="margin-top: 35vh;"><i class="fas fa-ban text-danger"></i> Page introuvable</h1>
    </body>
    <script>
        setTimeout(function(){
            window.location.href = "./index.php";
        },3000);
    </script>
</html>