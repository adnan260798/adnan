package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Crenau;



public interface CrenauRepository extends JpaRepository<Crenau, Integer> {

	Crenau findById(long id);
}
