package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.CrSalle;
import com.example.demo.repository.CrSalleRepository;
import com.example.demo.repository.CrenauRepository;
import com.example.demo.repository.SalleRepository;
import com.example.demo.repository.UserRepository;

@RestController
@RequestMapping("crSalles")
public class CrSalleController {
	@Autowired
	private CrSalleRepository crSalleRepository;

	@Autowired
	private CrenauRepository crenauRepository;
	
	@Autowired
	private SalleRepository salleRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@PostMapping("/save")
	public void save(@RequestBody CrSalle crSalle){
		System.out.println(crSalle);
		crSalle.setCrenau(crenauRepository.findById(crSalle.getCrenau().getId()));
		crSalle.setSalle(salleRepository.findById(crSalle.getSalle().getId()));
		crSalleRepository.save(crSalle);
	}
	
	@GetMapping("/all")
	public List<CrSalle> findAll(){
		return crSalleRepository.findAll();
	}
	
	@DeleteMapping(value = "/delete/{id}")
	public void delete(@PathVariable(required = true) int id) {
		System.out.println("id = "+id);
		CrSalle	crSalle = crSalleRepository.findById((id));
		crSalleRepository.delete(crSalle);
	}
}
