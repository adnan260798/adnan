package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CrSalleKey implements Serializable {
	private long salle;
	private long crenau;
	
	
	
	public CrSalleKey() {
		super();
	}
	public CrSalleKey(long salle, long crenau) {
		this.salle = salle;
		this.crenau = crenau;
	}
}
