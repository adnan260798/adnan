package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Crenau;
import com.example.demo.repository.CrenauRepository;
@RestController
@RequestMapping("crenaus")
public class CrenauController {
	@Autowired
	CrenauRepository crenauRepository;

	@PostMapping("/save")
	public void save(@RequestBody Crenau crenau){
		crenauRepository.save(crenau);
	}
	
	@GetMapping("/all")
	public List<Crenau> load(){
		return crenauRepository.findAll();
	}
	
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable long id){
		crenauRepository.delete(crenauRepository.findById(id));
	}
	
	@GetMapping("/count")
	public Map<String, Integer> count (){
		Map<String, Integer> map = new HashMap<>();
		for(Crenau m : crenauRepository.findAll()){
			map.put(m.getCode(), m.getCrsalles().size());
		}
		return map;
	}
}
