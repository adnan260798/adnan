package com.example.demo.model;

import java.util.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name="crSalle")
public class CrSalle {
	@EmbeddedId
	private CrSalleKey id;
	@Temporal(TemporalType.DATE)
	private Date date;
	@JoinColumn(name = "salle", referencedColumnName = "id", insertable = false, updatable = false)
	@ManyToOne
	private Salle salle;
	@JoinColumn(name = "crenau", referencedColumnName = "id", insertable = false, updatable = false)
	@ManyToOne
	private Crenau crenau;
	@JoinColumn(name = "user",  insertable = false, updatable = false)
	@ManyToOne
	private User user;
	public CrSalle() {
		
	}
	public CrSalle(Date date, Salle salle, Crenau crenau, User user) {
		super();
		this.date = date;
		this.salle = salle;
		this.crenau = crenau;
		this.user = user;
	}
	public CrSalle(CrSalleKey id, Date date, Salle salle, Crenau crenau, User user) {
		super();
		this.id = id;
		this.date = date;
		this.salle = salle;
		this.crenau = crenau;
		this.user = user;
	}
	public CrSalleKey getId() {
		return id;
	}
	public void setId(CrSalleKey id) {
		this.id = id;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Salle getSalle() {
		return salle;
	}
	public void setSalle(Salle salle) {
		this.salle = salle;
	}
	public Crenau getCrenau() {
		return crenau;
	}
	public void setCrenau(Crenau crenau) {
		this.crenau = crenau;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
	@Override
	public String toString() {
		return "CrSalle [id=" + id + ", date=" + date + ", salle=" + salle + ", crenau=" + crenau + ", user=" + user
				+ "]";
	}
}
