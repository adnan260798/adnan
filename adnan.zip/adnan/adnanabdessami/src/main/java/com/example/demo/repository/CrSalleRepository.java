package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.CrSalle;



public interface CrSalleRepository extends JpaRepository<CrSalle, Integer> {

	CrSalle findById(long id);
}
