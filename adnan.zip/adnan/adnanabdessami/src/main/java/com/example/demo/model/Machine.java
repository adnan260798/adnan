package com.example.demo.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;






@Entity
@Table(name="machine")
public class Machine {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String ref;
	@Temporal(TemporalType.DATE)
	private Date dateAchat;
	private double prix;
	@ManyToOne(cascade = CascadeType.PERSIST)
	private Marque marque;
	@ManyToOne(cascade = CascadeType.PERSIST)
	private Salle salle;
	
	public Machine() {
	}
	
	

	public Machine(String ref, Date dateAchat, double prix, Marque marque, Salle salle) {
		super();
		this.ref = ref;
		this.dateAchat = dateAchat;
		this.prix = prix;
		this.marque = marque;
		this.salle = salle;
	}
	


	public Machine(long id, String ref, Date dateAchat, double prix, Marque marque, Salle salle) {
		super();
		this.id = id;
		this.ref = ref;
		this.dateAchat = dateAchat;
		this.prix = prix;
		this.marque = marque;
		this.salle = salle;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public Date getDateAchat() {
		return dateAchat;
	}

	public void setDateAchat(Date dateAchat) {
		this.dateAchat = dateAchat;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}



	public Marque getMarque() {
		return marque;
	}



	public void setMarque(Marque marque) {
		this.marque = marque;
	}



	public Salle getSalle() {
		return salle;
	}



	public void setSalle(Salle salle) {
		this.salle = salle;
	}

	

	@Override
	public String toString() {
		return "Machine [id=" + id + ", ref=" + ref + ", dateAchat=" + dateAchat + ", prix=" + prix + ", marque="
				+ marque + ", salle=" + salle + "]";
	}
	
	
	

}
